using System;
using System.IO;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.Net;
using static System.Net.WebRequestMethods;

namespace IntelligentApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string APIKey = "628288ab629fad6ee5ba9bb46075dab2";

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                TextWriter writeFile = new StreamWriter("newline.txt");
                writeFile.WriteLine("Before New Line");
                writeFile.WriteLine(Environment.NewLine);
                writeFile.WriteLine("After New Line");
                writeFile.Flush();
                writeFile.Close();
                writeFile = null;
            }
            catch (IOException ex)
            {
                MessageBox.Show(ex.ToString());
            }
            label1.Text = Environment.CurrentDirectory;
            label2.Text = Environment.MachineName;
            label3.Text = Environment.OSVersion.ToString();
            label4.Text = Environment.UserName;
            label5.Text = Environment.OSVersion.Platform.ToString();
            label6.Text = Environment.OSVersion.Version.ToString();
            label7.Text = SystemInformation.PrimaryMonitorSize.ToString();
            label8.Text = Environment.UserDomainName.ToString();
            label9.Text = Environment.WorkingSet.ToString();
            label10.Text = Environment.SystemPageSize.ToString();
            label11.Text = Environment.SystemDirectory;
            label12.Text = Environment.ProcessorCount.ToString();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            getWeather();
        }

        double lon;
        double lat;

        void getWeather()
        {
            using (WebClient web = new WebClient())
            {
                string url = string.Format("https://api.openweathermap.org/data/2.5/weather?q={0}&appid={1}", TBCity.Text, APIKey);
                var json = web.DownloadString(url);
                WeatherInfo.root Info = JsonConvert DeserializeObject<WeatherInfo.root>(json);
                picIcon.ImageLocation = "http://openweathermap.org/img/w/02n.png" + Info.weather[0] + ".png";
                labCondition.Text = Info.weather[0].main;
                labDetails.Text = Info.weather[0].description;
                labSunset.Text = convertDateTime(Info.sys.sunset).ToShortTimeString();
                labSunrise.Text = convertDateTime(Info.sys.sunrise).ToShortTimeString();
                labWindSpeed.Text = Info.wind.speed.ToString();
                labPressure.Text = Info.main.pressure.ToString();
                lon = Info.coord.lon;
                lat = Info.coord.lat;
            }
        }

        DateTime convertDateTime(long sec)
        {
            DateTime day = new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc).ToLocalTime();
            day = day.AddSeconds(sec).ToLocalTime(); //A millisec itt hib�s!
            return day;
        }

        void getForecast()
        {
            using (WebClient web = new WebClient())
            {
                string url = string.Format("https://api.openweathermap.org/data/3.0/onecall?lat={0}&lon={1}&exclude=current,minutely,hourly,alerts&appid={2}", lon, lat, APIKey);
                var json = web.DownloadString(url);
                WeatherForecast.ForecastInfo ForecastInfo = JsonConvert DeserializeObject<WeatherForecast.ForecastInfo>(json);

                ForecastUC FUC;
                for (int i = 0; i < 8; i++)
                {
                    FUC = new ForecastUC();
                    FUC.picWeatherIcon.ImageLocation = "http://openweathermap.org/img/w/02n.png" + ForecastInfo.daily[i].weather[0].icon + ".png";
                    FUC.labMainWeather.Text = ForecastInfo.daily[i].weather[0].main;
                    FUC.labWeatherDescription.Text = ForecastInfo.daily[i].weather[0].description;
                    FUC.labDT.Text = convertDateTime(ForecastInfo.daily[i].dt).DayOfWeek.ToString();
                    FLP.Controls.Add(FUC);
                }
            }
        }
    }
}